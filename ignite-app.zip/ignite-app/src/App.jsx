
import { useState, useEffect, useRef, useCallback } from "react";

// ─── SYSTEM PROMPT ────────────────────────────────────────────────────────────
const SYSTEM = `Eres IGNITE — Motor de Estrategia y Producción Digital. Tu usuario es un EXPERTO que quiere monetizar su conocimiento. Al final de la sesión entregas DOS cosas: (1) Plan de negocio operativo 4 semanas, (2) Mini-curso completo listo para lanzar.

REGLA ABSOLUTA: UNA sola pregunta o entrega a la vez. Nunca agrupes.

═══════════════════════════════════════
FLUJO DE 5 FASES
═══════════════════════════════════════

FASE 1 — DIAGNÓSTICO
- Analiza lo que el usuario compartió (texto, archivos, ideas).
- Haz 1-2 preguntas abiertas para entender: ¿quién es el comprador exacto? ¿cuál es su dolor #1?
- Al terminar esta fase, emite un bloque JSON de diagnóstico:
|||CHART:radar|||{"labels":["Claridad de Nicho","Urgencia del Problema","Diferenciación","Potencial de Precio","Velocidad de Lanzamiento"],"values":[X,X,X,X,X],"title":"Diagnóstico de tu Idea"}|||

FASE 2 — PRODUCTO
- Define: nombre del curso, subtítulo, promesa principal, para quién es y para quién NO es.
- Al terminar, emite tabla de módulos:
|||TABLE|||{"title":"Estructura del Mini-Curso","headers":["#","Módulo","Contenido Clave","Formato","Duración"],"rows":[...]}|||

FASE 3 — PRECIO & POSICIONAMIENTO
- Define precio ancla, precio real, bonos incluidos.
- Al terminar, emite gráfica de precios:
|||CHART:bar|||{"labels":["Precio Mínimo","Tu Precio","Precio Premium","Competencia Promedio"],"values":[X,X,X,X],"title":"Mapa de Precios","color":"red"}|||

FASE 4 — EMBUDO
- Define: lead magnet, página de captura, secuencia email (3 emails), cierre de venta.
- Al terminar, emite tabla del embudo:
|||TABLE|||{"title":"Tu Embudo de Ventas","headers":["Etapa","Acción","Herramienta","Métrica"],"rows":[...]}|||

FASE 5 — LANZAMIENTO
- Define semana 1, 2, 3, 4 con acciones concretas.
- Al terminar emite: |||ENTREGAR_PRODUCTO|||

═══════════════════════════════════════
REGLAS DE VISUALIZACIÓN
═══════════════════════════════════════
- Emite los bloques JSON al FINAL de tu mensaje, después del texto.
- Los valores del radar van de 0 a 100.
- Las tablas deben tener datos REALES basados en la conversación, no placeholders genéricos.
- Sé específico: nombres reales, números reales, acciones reales.

TONO: Audaz. Directo. Máximo 3 líneas de texto antes de la pregunta o entrega. Sin relleno.`;

const PRODUCT_SYSTEM = `Eres un diseñador de productos digitales. Basándote en la conversación completa, genera un mini-curso completo en JSON.

Devuelve SOLO un objeto JSON válido, sin markdown, sin explicaciones:
{
  "course": {
    "name": "Nombre del curso",
    "tagline": "Subtítulo impactante en menos de 10 palabras",
    "promise": "Promesa principal: resultado específico en tiempo específico",
    "target": "Para quién es exactamente",
    "notFor": "Para quién NO es",
    "price": 000,
    "originalPrice": 000,
    "instructor": "Nombre del experto (usar 'Tu Nombre' si no se dio)",
    "modules": [
      {
        "number": 1,
        "title": "Título del módulo",
        "description": "Descripción de 1 línea",
        "lessons": ["Lección 1","Lección 2","Lección 3"],
        "duration": "X horas",
        "format": "Video / PDF / Workshop"
      }
    ],
    "bonuses": ["Bono 1","Bono 2"],
    "testimonialPlaceholders": 3,
    "launchDate": "Semana X",
    "primaryColor": "#dc2626",
    "accentColor": "#ffffff"
  },
  "businessPlan": {
    "week1": ["acción 1","acción 2","acción 3"],
    "week2": ["acción 1","acción 2","acción 3"],
    "week3": ["acción 1","acción 2","acción 3"],
    "week4": ["acción 1","acción 2","acción 3"],
    "tools": ["herramienta 1","herramienta 2","herramienta 3"],
    "kpis": ["KPI 1: meta","KPI 2: meta","KPI 3: meta"]
  }
}`;

// ─── HELPERS ──────────────────────────────────────────────────────────────────
const toBase64 = (file) => new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result.split(",")[1]); r.onerror=rej; r.readAsDataURL(file); });
const now = () => new Date().toLocaleTimeString("es",{hour:"2-digit",minute:"2-digit"});

function parseMessageBlocks(content) {
  const blocks = [];
  let remaining = content;
  const patterns = [
    { type:"chart", re:/\|\|\|CHART:(radar|bar|line)\|\|\|([\s\S]*?)\|\|\|/g },
    { type:"table", re:/\|\|\|TABLE\|\|\|([\s\S]*?)\|\|\|/g },
    { type:"deliver", re:/\|\|\|ENTREGAR_PRODUCTO\|\|\|/g },
  ];
  // collect all special blocks with positions
  const found = [];
  for(const {type,re} of patterns){
    let m;
    const rx = new RegExp(re.source, re.flags);
    while((m=rx.exec(content))!==null){
      found.push({type, match:m[0], start:m.index, end:m.index+m[0].length,
        subtype: type==="chart"?m[1]:null,
        data: type==="chart"?m[2]: type==="table"?m[1]:null
      });
    }
  }
  found.sort((a,b)=>a.start-b.start);
  let cursor=0;
  for(const f of found){
    if(f.start>cursor){ const txt=content.slice(cursor,f.start).trim(); if(txt) blocks.push({type:"text",content:txt}); }
    if(f.type==="chart"){ try{ blocks.push({type:"chart",subtype:f.subtype,data:JSON.parse(f.data)}); }catch{} }
    if(f.type==="table"){ try{ blocks.push({type:"table",data:JSON.parse(f.data)}); }catch{} }
    if(f.type==="deliver"){ blocks.push({type:"deliver"}); }
    cursor=f.end;
  }
  if(cursor<content.length){ const txt=content.slice(cursor).trim(); if(txt) blocks.push({type:"text",content:txt}); }
  if(blocks.length===0) blocks.push({type:"text",content});
  return blocks;
}

// ─── VISUAL COMPONENTS ────────────────────────────────────────────────────────

function RadarChart({data}) {
  const {labels,values,title} = data;
  const cx=160, cy=155, r=110, n=labels.length;
  const angle = (i) => (Math.PI*2*i/n) - Math.PI/2;
  const pt = (i,pct) => ({ x: cx + r*(pct/100)*Math.cos(angle(i)), y: cy + r*(pct/100)*Math.sin(angle(i)) });
  const gridLevels = [20,40,60,80,100];
  const [animated, setAnimated] = useState(false);
  useEffect(()=>{ setTimeout(()=>setAnimated(true),200); },[]);
  const aValues = animated ? values : values.map(()=>0);

  return (
    <div style={{background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:4,padding:"20px 16px",position:"relative"}}>
      <div style={{fontSize:9,color:"#dc2626",fontFamily:"'DM Mono',monospace",letterSpacing:"3px",textTransform:"uppercase",marginBottom:12}}>{title}</div>
      <svg width="100%" viewBox="0 0 320 310" style={{overflow:"visible"}}>
        {gridLevels.map(lvl=>(
          <polygon key={lvl}
            points={labels.map((_,i)=>{ const p=pt(i,lvl); return `${p.x},${p.y}`; }).join(" ")}
            fill="none" stroke="rgba(255,255,255,0.05)" strokeWidth="1"/>
        ))}
        {labels.map((_,i)=>(
          <line key={i} x1={cx} y1={cy} x2={pt(i,100).x} y2={pt(i,100).y} stroke="rgba(255,255,255,0.07)" strokeWidth="1"/>
        ))}
        <polygon
          points={aValues.map((_,i)=>{ const p=pt(i,aValues[i]); return `${p.x},${p.y}`; }).join(" ")}
          fill="rgba(220,38,38,0.12)" stroke="#dc2626" strokeWidth="1.5"
          style={{transition:"all 0.8s ease"}}/>
        {aValues.map((v,i)=>{ const p=pt(i,v); return <circle key={i} cx={p.x} cy={p.y} r="4" fill="#dc2626" style={{transition:"all 0.8s ease"}}/> })}
        {labels.map((lbl,i)=>{
          const p=pt(i,118);
          return <text key={i} x={p.x} y={p.y} textAnchor="middle" dominantBaseline="middle"
            fill="rgba(255,255,255,0.5)" fontSize="9" fontFamily="'DM Mono',monospace">{lbl}</text>;
        })}
        {aValues.map((v,i)=>{ const p=pt(i,v+12); return <text key={i} x={p.x} y={p.y} textAnchor="middle" fill="#dc2626" fontSize="9" fontFamily="'DM Mono',monospace" fontWeight="700">{v}</text>; })}
      </svg>
    </div>
  );
}

function BarChart({data}) {
  const {labels,values,title} = data;
  const max = Math.max(...values)*1.2;
  const [animated,setAnimated]=useState(false);
  useEffect(()=>{ setTimeout(()=>setAnimated(true),200); },[]);
  return (
    <div style={{background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:4,padding:"20px 16px"}}>
      <div style={{fontSize:9,color:"#dc2626",fontFamily:"'DM Mono',monospace",letterSpacing:"3px",textTransform:"uppercase",marginBottom:16}}>{title}</div>
      <div style={{display:"flex",alignItems:"flex-end",gap:12,height:140,paddingBottom:4}}>
        {values.map((v,i)=>(
          <div key={i} style={{flex:1,display:"flex",flexDirection:"column",alignItems:"center",gap:6,height:"100%",justifyContent:"flex-end"}}>
            <span style={{fontSize:10,color:"#fff",fontFamily:"'DM Mono',monospace",fontWeight:700}}>${v}</span>
            <div style={{
              width:"100%",background: i===1?"#dc2626":"rgba(255,255,255,0.1)",
              height:animated?`${(v/max)*100}%`:"0%",
              transition:"height 0.9s cubic-bezier(0.34,1.56,0.64,1)",
              borderRadius:"2px 2px 0 0",
              position:"relative"
            }}>
              {i===1 && <div style={{position:"absolute",inset:0,background:"linear-gradient(180deg,rgba(220,38,38,0.3) 0%,transparent 100%)"}}/>}
            </div>
          </div>
        ))}
      </div>
      <div style={{display:"flex",gap:12,marginTop:8}}>
        {labels.map((l,i)=>(
          <div key={i} style={{flex:1,textAlign:"center",fontSize:8,color: i===1?"rgba(220,38,38,0.8)":"rgba(255,255,255,0.3)",fontFamily:"'DM Mono',monospace",letterSpacing:"0.5px"}}>{l}</div>
        ))}
      </div>
    </div>
  );
}

function DataTable({data}) {
  const {title,headers,rows} = data;
  return (
    <div style={{background:"rgba(0,0,0,0.6)",border:"1px solid rgba(255,255,255,0.07)",borderRadius:4,overflow:"hidden"}}>
      <div style={{padding:"12px 16px",borderBottom:"1px solid rgba(220,38,38,0.2)",display:"flex",alignItems:"center",gap:10}}>
        <div style={{width:3,height:16,background:"#dc2626"}}/>
        <span style={{fontSize:9,color:"rgba(255,255,255,0.7)",fontFamily:"'DM Mono',monospace",letterSpacing:"2px",textTransform:"uppercase"}}>{title}</span>
      </div>
      <div style={{overflowX:"auto"}}>
        <table style={{width:"100%",borderCollapse:"collapse"}}>
          <thead>
            <tr style={{background:"rgba(255,255,255,0.02)"}}>
              {headers.map((h,i)=>(
                <th key={i} style={{padding:"8px 14px",textAlign:"left",fontSize:9,color:"#dc2626",fontFamily:"'DM Mono',monospace",letterSpacing:"1px",borderBottom:"1px solid rgba(255,255,255,0.05)",whiteSpace:"nowrap"}}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((row,i)=>(
              <tr key={i} style={{borderBottom:"1px solid rgba(255,255,255,0.03)",transition:"background 0.2s"}}
                onMouseEnter={e=>e.currentTarget.style.background="rgba(220,38,38,0.04)"}
                onMouseLeave={e=>e.currentTarget.style.background="transparent"}>
                {row.map((cell,j)=>(
                  <td key={j} style={{padding:"9px 14px",fontSize:11,color: j===0?"rgba(255,255,255,0.8)":"rgba(255,255,255,0.5)",fontFamily:"'DM Mono',monospace",lineHeight:1.5}}>{cell}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// ─── LANDING PAGE PREVIEW ─────────────────────────────────────────────────────
function CourseLanding({course}) {
  const [tab,setTab]=useState("landing");
  const tabStyle = (t) => ({
    padding:"8px 18px",fontSize:9,fontFamily:"'DM Mono',monospace",letterSpacing:"2px",
    textTransform:"uppercase",cursor:"pointer",border:"none",
    background: tab===t?"#dc2626":"transparent",
    color: tab===t?"#fff":"rgba(255,255,255,0.3)",
    borderBottom: tab===t?"2px solid #dc2626":"2px solid transparent",
    transition:"all 0.2s"
  });

  return (
    <div style={{background:"#000",border:"1px solid rgba(255,255,255,0.08)",borderRadius:4,overflow:"hidden"}}>
      {/* Tab bar */}
      <div style={{display:"flex",borderBottom:"1px solid rgba(255,255,255,0.06)",background:"rgba(0,0,0,0.8)"}}>
        {["landing","modulos","plan"].map(t=>(
          <button key={t} style={tabStyle(t)} onClick={()=>setTab(t)}>
            {t==="landing"?"Landing Page":t==="modulos"?"Módulos del Curso":"Plan 4 Semanas"}
          </button>
        ))}
      </div>

      {tab==="landing" && (
        <div style={{fontFamily:"'Syne',sans-serif"}}>
          {/* Hero */}
          <div style={{
            padding:"60px 40px",
            background:"linear-gradient(135deg,#000 0%,#0a0a0a 50%,#110000 100%)",
            borderBottom:"1px solid rgba(220,38,38,0.15)",
            position:"relative",overflow:"hidden"
          }}>
            <div style={{position:"absolute",top:0,left:0,right:0,bottom:0,
              backgroundImage:"linear-gradient(rgba(220,38,38,0.03) 1px,transparent 1px),linear-gradient(90deg,rgba(220,38,38,0.03) 1px,transparent 1px)",
              backgroundSize:"40px 40px"}}/>
            <div style={{position:"relative"}}>
              <div style={{fontSize:10,color:"#dc2626",letterSpacing:"4px",fontFamily:"'DM Mono',monospace",marginBottom:16,textTransform:"uppercase"}}>
                Mini-Curso Digital
              </div>
              <h1 style={{fontSize:"clamp(28px,5vw,52px)",fontWeight:800,color:"#fff",letterSpacing:"-2px",lineHeight:1,marginBottom:12}}>
                {course.name}
              </h1>
              <p style={{fontSize:16,color:"rgba(255,255,255,0.5)",marginBottom:8,fontFamily:"'DM Mono',monospace",fontWeight:300}}>
                {course.tagline}
              </p>
              <p style={{fontSize:13,color:"rgba(220,38,38,0.8)",marginBottom:32,fontFamily:"'DM Mono',monospace"}}>
                {course.promise}
              </p>
              {/* Photo placeholder */}
              <div style={{
                width:80,height:80,borderRadius:"50%",
                border:"2px dashed rgba(255,255,255,0.15)",
                display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",
                marginBottom:16,background:"rgba(255,255,255,0.02)"
              }}>
                <span style={{fontSize:20}}>👤</span>
                <span style={{fontSize:7,color:"rgba(255,255,255,0.2)",fontFamily:"'DM Mono',monospace",marginTop:4}}>TU FOTO</span>
              </div>
              <div style={{fontSize:12,color:"rgba(255,255,255,0.5)",fontFamily:"'DM Mono',monospace"}}>{course.instructor}</div>
              {/* CTA */}
              <div style={{marginTop:32,display:"flex",alignItems:"center",gap:20,flexWrap:"wrap"}}>
                <div>
                  <div style={{fontSize:11,color:"rgba(255,255,255,0.3)",fontFamily:"'DM Mono',monospace",textDecoration:"line-through"}}>${course.originalPrice}</div>
                  <div style={{fontSize:36,fontWeight:800,color:"#fff",letterSpacing:"-2px"}}>${course.price} <span style={{fontSize:14,color:"rgba(255,255,255,0.4)",fontWeight:400}}>USD</span></div>
                </div>
                <button style={{
                  background:"#dc2626",border:"none",color:"#fff",
                  padding:"16px 36px",borderRadius:2,cursor:"pointer",
                  fontSize:12,fontWeight:700,letterSpacing:"2px",
                  fontFamily:"'DM Mono',monospace",textTransform:"uppercase"
                }}>Quiero Acceso →</button>
              </div>
            </div>
          </div>

          {/* Para quién */}
          <div style={{padding:"32px 40px",display:"grid",gridTemplateColumns:"1fr 1fr",gap:16}}>
            <div style={{border:"1px solid rgba(255,255,255,0.06)",padding:20,borderRadius:4}}>
              <div style={{fontSize:10,color:"rgba(255,255,255,0.4)",fontFamily:"'DM Mono',monospace",letterSpacing:"2px",marginBottom:12}}>✓ PARA QUIÉN ES</div>
              <p style={{fontSize:13,color:"rgba(255,255,255,0.7)",fontFamily:"'DM Mono',monospace",lineHeight:1.7}}>{course.target}</p>
            </div>
            <div style={{border:"1px solid rgba(220,38,38,0.1)",padding:20,borderRadius:4,background:"rgba(220,38,38,0.02)"}}>
              <div style={{fontSize:10,color:"rgba(220,38,38,0.6)",fontFamily:"'DM Mono',monospace",letterSpacing:"2px",marginBottom:12}}>✕ PARA QUIÉN NO ES</div>
              <p style={{fontSize:13,color:"rgba(255,255,255,0.5)",fontFamily:"'DM Mono',monospace",lineHeight:1.7}}>{course.notFor}</p>
            </div>
          </div>

          {/* Bonos */}
          {course.bonuses?.length > 0 && (
            <div style={{padding:"0 40px 32px"}}>
              <div style={{fontSize:10,color:"#dc2626",fontFamily:"'DM Mono',monospace",letterSpacing:"3px",marginBottom:12}}>INCLUYE TAMBIÉN</div>
              {course.bonuses.map((b,i)=>(
                <div key={i} style={{display:"flex",gap:10,padding:"10px 0",borderBottom:"1px solid rgba(255,255,255,0.04)"}}>
                  <span style={{color:"#dc2626",fontSize:12}}>⊕</span>
                  <span style={{fontSize:12,color:"rgba(255,255,255,0.6)",fontFamily:"'DM Mono',monospace"}}>{b}</span>
                </div>
              ))}
            </div>
          )}

          {/* Testimonios placeholder */}
          <div style={{padding:"0 40px 40px"}}>
            <div style={{fontSize:10,color:"rgba(255,255,255,0.3)",fontFamily:"'DM Mono',monospace",letterSpacing:"3px",marginBottom:16}}>LO QUE DICEN</div>
            <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:12}}>
              {Array(course.testimonialPlaceholders||3).fill(0).map((_,i)=>(
                <div key={i} style={{border:"1px dashed rgba(255,255,255,0.08)",padding:16,borderRadius:4,background:"rgba(255,255,255,0.01)"}}>
                  <div style={{width:36,height:36,borderRadius:"50%",border:"1px dashed rgba(255,255,255,0.1)",display:"flex",alignItems:"center",justifyContent:"center",marginBottom:10}}>
                    <span style={{fontSize:14}}>👤</span>
                  </div>
                  <div style={{height:8,background:"rgba(255,255,255,0.05)",borderRadius:2,marginBottom:6,width:"80%"}}/>
                  <div style={{height:8,background:"rgba(255,255,255,0.05)",borderRadius:2,marginBottom:6}}/>
                  <div style={{height:8,background:"rgba(255,255,255,0.05)",borderRadius:2,width:"60%"}}/>
                  <div style={{marginTop:10,fontSize:8,color:"rgba(255,255,255,0.15)",fontFamily:"'DM Mono',monospace"}}>TESTIMONIO {i+1}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {tab==="modulos" && (
        <div style={{padding:32}}>
          <div style={{fontSize:9,color:"#dc2626",fontFamily:"'DM Mono',monospace",letterSpacing:"3px",marginBottom:24}}>ESTRUCTURA DEL CURSO</div>
          {course.modules?.map((mod,i)=>(
            <div key={i} style={{
              border:"1px solid rgba(255,255,255,0.06)",borderRadius:4,marginBottom:12,
              overflow:"hidden",transition:"border-color 0.2s"
            }}>
              <div style={{
                padding:"16px 20px",
                background:"rgba(255,255,255,0.02)",
                display:"flex",alignItems:"center",gap:16
              }}>
                <div style={{
                  width:36,height:36,border:"1px solid rgba(220,38,38,0.3)",
                  borderRadius:4,display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0
                }}>
                  <span style={{fontSize:12,color:"#dc2626",fontFamily:"'DM Mono',monospace",fontWeight:700}}>0{mod.number}</span>
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:14,fontWeight:600,color:"#fff",fontFamily:"'Syne',sans-serif",letterSpacing:"-0.3px"}}>{mod.title}</div>
                  <div style={{fontSize:10,color:"rgba(255,255,255,0.4)",fontFamily:"'DM Mono',monospace",marginTop:2}}>{mod.description}</div>
                </div>
                <div style={{display:"flex",gap:8,flexShrink:0}}>
                  <span style={{fontSize:9,color:"rgba(255,255,255,0.3)",fontFamily:"'DM Mono',monospace",padding:"3px 8px",border:"1px solid rgba(255,255,255,0.06)",borderRadius:2}}>{mod.duration}</span>
                  <span style={{fontSize:9,color:"rgba(220,38,38,0.7)",fontFamily:"'DM Mono',monospace",padding:"3px 8px",border:"1px solid rgba(220,38,38,0.15)",borderRadius:2}}>{mod.format}</span>
                </div>
              </div>
              <div style={{padding:"12px 20px 16px 72px"}}>
                {mod.lessons?.map((l,j)=>(
                  <div key={j} style={{display:"flex",gap:10,padding:"5px 0",borderBottom:"1px solid rgba(255,255,255,0.02)"}}>
                    <span style={{color:"rgba(220,38,38,0.4)",fontSize:9,fontFamily:"'DM Mono',monospace",minWidth:14}}>{j+1}.</span>
                    <span style={{fontSize:12,color:"rgba(255,255,255,0.5)",fontFamily:"'DM Mono',monospace"}}>{l}</span>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==="plan" && (
        <div style={{padding:32}}>
          <div style={{fontSize:9,color:"#dc2626",fontFamily:"'DM Mono',monospace",letterSpacing:"3px",marginBottom:24}}>PLAN OPERATIVO · 4 SEMANAS</div>
          <div style={{display:"grid",gridTemplateColumns:"repeat(auto-fit,minmax(200px,1fr))",gap:12,marginBottom:24}}>
            {["week1","week2","week3","week4"].map((w,i)=>(
              <div key={w} style={{border:"1px solid rgba(255,255,255,0.06)",borderRadius:4,overflow:"hidden"}}>
                <div style={{
                  padding:"10px 14px",
                  background: i===0?"rgba(220,38,38,0.08)":"rgba(255,255,255,0.02)",
                  borderBottom:"1px solid rgba(255,255,255,0.05)",
                  display:"flex",alignItems:"center",gap:8
                }}>
                  <div style={{width:6,height:6,borderRadius:"50%",background: i===0?"#dc2626":"rgba(255,255,255,0.2)"}}/>
                  <span style={{fontSize:9,color: i===0?"#dc2626":"rgba(255,255,255,0.4)",fontFamily:"'DM Mono',monospace",letterSpacing:"2px"}}>SEMANA {i+1}</span>
                </div>
                <div style={{padding:14}}>
                  {(course.businessPlan?.[w]||[]).map((a,j)=>(
                    <div key={j} style={{display:"flex",gap:8,padding:"5px 0",borderBottom:"1px solid rgba(255,255,255,0.03)"}}>
                      <span style={{color:"rgba(220,38,38,0.4)",fontSize:10}}>→</span>
                      <span style={{fontSize:11,color:"rgba(255,255,255,0.55)",fontFamily:"'DM Mono',monospace",lineHeight:1.5}}>{a}</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
          {/* KPIs */}
          <div style={{border:"1px solid rgba(220,38,38,0.15)",borderRadius:4,padding:20,marginBottom:16}}>
            <div style={{fontSize:9,color:"#dc2626",fontFamily:"'DM Mono',monospace",letterSpacing:"2px",marginBottom:12}}>KPIs DE ÉXITO</div>
            {(course.businessPlan?.kpis||[]).map((k,i)=>(
              <div key={i} style={{fontSize:11,color:"rgba(255,255,255,0.6)",fontFamily:"'DM Mono',monospace",padding:"5px 0",display:"flex",gap:10}}>
                <span style={{color:"#dc2626"}}>◆</span>{k}
              </div>
            ))}
          </div>
          {/* Tools */}
          <div>
            <div style={{fontSize:9,color:"rgba(255,255,255,0.3)",fontFamily:"'DM Mono',monospace",letterSpacing:"2px",marginBottom:10}}>HERRAMIENTAS (COSTO $0)</div>
            <div style={{display:"flex",gap:8,flexWrap:"wrap"}}>
              {(course.businessPlan?.tools||[]).map((t,i)=>(
                <span key={i} style={{fontSize:10,color:"rgba(255,255,255,0.5)",fontFamily:"'DM Mono',monospace",padding:"5px 12px",border:"1px solid rgba(255,255,255,0.07)",borderRadius:2}}>{t}</span>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── MESSAGE RENDERER ─────────────────────────────────────────────────────────
function Message({msg, onDeliver}) {
  const [vis,setVis]=useState(false);
  useEffect(()=>{ setTimeout(()=>setVis(true),30); },[]);
  const isUser = msg.role==="user";
  const blocks = isUser ? [{type:"text",content:msg.content}] : parseMessageBlocks(msg.content||"");

  useEffect(()=>{
    if(!isUser && blocks.some(b=>b.type==="deliver")) onDeliver?.();
  },[]);

  const renderText = (text) => text.split("\n").map((line,i)=>{
    if(line.startsWith("**")&&line.endsWith("**")) return <p key={i} style={{fontWeight:700,color:"#fff",margin:"8px 0 4px",fontSize:14,fontFamily:"'Syne',sans-serif"}}>{line.slice(2,-2)}</p>;
    if(/^[A-D]\)/.test(line)) return (
      <div key={i} style={{display:"flex",gap:10,margin:"4px 0",padding:"8px 12px",background:"rgba(255,255,255,0.02)",border:"1px solid rgba(255,255,255,0.05)",borderRadius:3}}>
        <span style={{color:"#dc2626",fontFamily:"'DM Mono',monospace",fontSize:10,fontWeight:700,minWidth:16}}>{line[0]}</span>
        <span style={{color:"rgba(255,255,255,0.7)",fontSize:13,lineHeight:1.6,fontFamily:"'DM Mono',monospace"}}>{line.slice(2).trim()}</span>
      </div>
    );
    if(line.trim()==="") return <div key={i} style={{height:5}}/>;
    return <p key={i} style={{margin:"3px 0",color:isUser?"rgba(255,255,255,0.5)":"rgba(255,255,255,0.8)",fontSize:13,lineHeight:1.75,fontFamily:"'DM Mono',monospace"}}>{line}</p>;
  });

  return (
    <div style={{opacity:vis?1:0,transform:vis?"translateY(0)":"translateY(8px)",transition:"all 0.35s ease",marginBottom:24,display:"flex",gap:12,flexDirection:isUser?"row-reverse":"row",alignItems:"flex-start"}}>
      <div style={{
        width:26,height:26,borderRadius:3,flexShrink:0,
        background:isUser?"rgba(255,255,255,0.04)":"rgba(220,38,38,0.1)",
        border:`1px solid ${isUser?"rgba(255,255,255,0.08)":"rgba(220,38,38,0.25)"}`,
        display:"flex",alignItems:"center",justifyContent:"center",
        fontSize:8,color:isUser?"rgba(255,255,255,0.3)":"#dc2626",fontFamily:"'DM Mono',monospace",marginTop:2
      }}>{isUser?"YOU":"IGN"}</div>

      <div style={{maxWidth:"82%",minWidth:0}}>
        {msg.files?.length>0 && (
          <div style={{display:"flex",flexWrap:"wrap",gap:6,marginBottom:8}}>
            {msg.files.map((f,i)=>(
              <span key={i} style={{fontSize:10,color:"rgba(255,255,255,0.4)",fontFamily:"'DM Mono',monospace",padding:"3px 9px",border:"1px solid rgba(255,255,255,0.07)",borderRadius:2}}>📎 {f}</span>
            ))}
          </div>
        )}
        {blocks.map((b,i)=>(
          <div key={i} style={{marginBottom: b.type!=="text"?12:0}}>
            {b.type==="text" && renderText(b.content)}
            {b.type==="chart" && b.subtype==="radar" && <RadarChart data={b.data}/>}
            {b.type==="chart" && b.subtype==="bar" && <BarChart data={b.data}/>}
            {b.type==="table" && <DataTable data={b.data}/>}
            {b.type==="deliver" && (
              <div style={{padding:"12px 16px",background:"rgba(220,38,38,0.08)",border:"1px solid rgba(220,38,38,0.2)",borderRadius:4,fontSize:12,color:"rgba(220,38,38,0.9)",fontFamily:"'DM Mono',monospace",letterSpacing:"1px"}}>
                ⚡ Generando tu producto digital...
              </div>
            )}
          </div>
        ))}
        <div style={{fontSize:8,color:"rgba(255,255,255,0.15)",fontFamily:"'DM Mono',monospace",marginTop:6,letterSpacing:"1px"}}>{msg.time}</div>
      </div>
    </div>
  );
}

// ─── LANDING ──────────────────────────────────────────────────────────────────
function Landing({onStart}) {
  const [v,setV]=useState(false);
  useEffect(()=>{ setTimeout(()=>setV(true),80); },[]);
  return (
    <div style={{minHeight:"100vh",display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center",padding:"48px 24px",opacity:v?1:0,transition:"opacity 1s ease"}}>
      <div style={{position:"relative",marginBottom:44}}>
        <div style={{width:64,height:64,border:"1px solid rgba(220,38,38,0.35)",display:"flex",alignItems:"center",justifyContent:"center",position:"relative",borderRadius:4}}>
          {["tl","tr","bl","br"].map(p=>{
            const s={position:"absolute",width:10,height:10};
            const b="1.5px solid #dc2626";
            const cs={tl:{top:-1,left:-1,borderTop:b,borderLeft:b},tr:{top:-1,right:-1,borderTop:b,borderRight:b},bl:{bottom:-1,left:-1,borderBottom:b,borderLeft:b},br:{bottom:-1,right:-1,borderBottom:b,borderRight:b}};
            return <div key={p} style={{...s,...cs[p]}}/>;
          })}
          <span style={{fontSize:26}}>⚡</span>
        </div>
        <div style={{position:"absolute",top:"50%",left:"50%",transform:"translate(-50%,-50%)",width:120,height:120,borderRadius:"50%",background:"radial-gradient(circle,rgba(220,38,38,0.07) 0%,transparent 70%)",pointerEvents:"none"}}/>
      </div>

      <div style={{textAlign:"center",maxWidth:580,marginBottom:52}}>
        <div style={{fontSize:8,color:"#dc2626",letterSpacing:"6px",fontFamily:"'DM Mono',monospace",marginBottom:14,textTransform:"uppercase"}}>Product Strategy Engine v3</div>
        <h1 style={{fontFamily:"'Syne',sans-serif",fontSize:"clamp(52px,9vw,88px)",fontWeight:800,letterSpacing:"-4px",lineHeight:0.88,color:"#fff",margin:"0 0 22px"}}>IGNITE</h1>
        <p style={{color:"rgba(255,255,255,0.28)",fontSize:13,lineHeight:1.9,fontFamily:"'DM Mono',monospace",fontWeight:300}}>
          De idea a producto digital lanzado.<br/>
          Estrategia <span style={{color:"rgba(220,38,38,0.6)"}}>+</span> Landing Page <span style={{color:"rgba(220,38,38,0.6)"}}>+</span> Módulos <span style={{color:"rgba(220,38,38,0.6)"}}>+</span> Plan de 4 semanas.
        </p>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"repeat(5,1fr)",gap:0,marginBottom:48,width:"100%",maxWidth:540,border:"1px solid rgba(255,255,255,0.05)",borderRadius:4,overflow:"hidden"}}>
        {["Diagnóstico","Audiencia","Producto","Precios","Lanzamiento"].map((p,i)=>(
          <div key={i} style={{padding:"14px 8px",textAlign:"center",borderRight: i<4?"1px solid rgba(255,255,255,0.04)":"none",background:"rgba(255,255,255,0.01)"}}>
            <div style={{fontSize:8,color:"rgba(220,38,38,0.5)",fontFamily:"'DM Mono',monospace",marginBottom:5,letterSpacing:"1px"}}>0{i+1}</div>
            <div style={{fontSize:9,color:"rgba(255,255,255,0.25)",fontFamily:"'DM Mono',monospace",letterSpacing:"0.3px"}}>{p}</div>
          </div>
        ))}
      </div>

      <button onClick={onStart} style={{
        background:"#dc2626",border:"none",color:"#fff",
        padding:"15px 44px",borderRadius:2,cursor:"pointer",
        fontSize:10,fontWeight:700,letterSpacing:"5px",
        textTransform:"uppercase",fontFamily:"'DM Mono',monospace",
        boxShadow:"0 0 40px rgba(220,38,38,0.2)",transition:"all 0.3s ease"
      }}
      onMouseEnter={e=>{e.target.style.boxShadow="0 0 60px rgba(220,38,38,0.5)";e.target.style.transform="translateY(-2px)";}}
      onMouseLeave={e=>{e.target.style.boxShadow="0 0 40px rgba(220,38,38,0.2)";e.target.style.transform="translateY(0)";}}>
        Comenzar →
      </button>
    </div>
  );
}

// ─── MAIN ─────────────────────────────────────────────────────────────────────
export default function Ignite() {
  const [screen,setScreen]     = useState("landing");
  const [messages,setMessages] = useState([]);
  const [apiHist,setApiHist]   = useState([]);
  const [input,setInput]       = useState("");
  const [files,setFiles]       = useState([]);
  const [loading,setLoading]   = useState(false);
  const [phase,setPhase]       = useState(0);
  const [phaseDone,setPhaseDone]= useState(0);
  const [courseData,setCourseData]= useState(null);
  const [genLoading,setGenLoading]= useState(false);
  const [dragOver,setDragOver] = useState(false);
  const fileRef  = useRef();
  const bottomRef= useRef();
  const taRef    = useRef();

  useEffect(()=>{ bottomRef.current?.scrollIntoView({behavior:"smooth"}); },[messages,loading,genLoading]);

  const detectPhase = (t) => {
    const l=t.toLowerCase();
    if(l.includes("fase 2")||l.includes("audiencia")||l.includes("comprador")) return 1;
    if(l.includes("fase 3")||l.includes("producto")||l.includes("módulos")) return 2;
    if(l.includes("fase 4")||l.includes("precio")||l.includes("embudo")) return 3;
    if(l.includes("fase 5")||l.includes("lanzamiento")) return 4;
    return null;
  };

  const callAPI = async (hist) => {
    const r = await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:1500,system:SYSTEM,messages:hist})});
    const d=await r.json();
    return d.content.map(b=>b.text||"").join("");
  };

  const generateProduct = async (hist) => {
    setGenLoading(true);
    const r = await fetch("https://api.anthropic.com/v1/messages",{method:"POST",headers:{"Content-Type":"application/json"},
      body:JSON.stringify({model:"claude-sonnet-4-20250514",max_tokens:2000,system:PRODUCT_SYSTEM,
        messages:[...hist,{role:"user",content:"Genera el producto completo basado en toda la conversación. Solo JSON."}]
      })});
    const d=await r.json();
    const txt=d.content.map(b=>b.text||"").join("").replace(/```json|```/g,"").trim();
    try { const parsed=JSON.parse(txt); setCourseData({...parsed.course,businessPlan:parsed.businessPlan}); setScreen("product"); }
    catch(e){ setCourseData({name:"Tu Mini-Curso",tagline:"El producto de tu conocimiento",promise:"Resultado claro en tiempo claro",target:"Tu audiencia ideal",notFor:"Quien no está listo",price:297,originalPrice:497,instructor:"Tu Nombre",modules:[],bonuses:[],testimonialPlaceholders:3,businessPlan:{week1:[],week2:[],week3:[],week4:[],tools:[],kpis:[]}}); setScreen("product"); }
    setGenLoading(false);
  };

  const startSession = async () => {
    setScreen("session"); setLoading(true);
    const init=[{role:"user",content:"Comienza la sesión. Soy un experto que quiere monetizar su conocimiento."}];
    setApiHist(init);
    try { const r=await callAPI(init); const h=[...init,{role:"assistant",content:r}]; setApiHist(h); setMessages([{role:"assistant",content:r,time:now()}]); }
    catch{ setMessages([{role:"assistant",content:"Error de conexión.",time:now()}]); }
    setLoading(false);
  };

  const handleFiles = (fl) => setFiles(prev=>[...prev,...Array.from(fl)].slice(0,5));

  const sendMessage = useCallback(async()=>{
    const text=input.trim();
    if(!text&&files.length===0||loading) return;
    const uiMsg={role:"user",content:text||(files.length>0?"(archivos adjuntos)":""),files:files.map(f=>f.name),time:now()};
    setMessages(prev=>[...prev,uiMsg]);
    setInput(""); const sf=[...files]; setFiles([]); setLoading(true);

    let apiContent=[];
    for(const f of sf){
      if(f.type.startsWith("image/")){const b=await toBase64(f);apiContent.push({type:"image",source:{type:"base64",media_type:f.type,data:b}});}
      else if(f.type==="application/pdf"){const b=await toBase64(f);apiContent.push({type:"document",source:{type:"base64",media_type:"application/pdf",data:b}});}
      else{try{const t=await f.text();apiContent.push({type:"text",text:`[${f.name}]\n${t.slice(0,3000)}`});}catch{apiContent.push({type:"text",text:`[Archivo: ${f.name}]`});}}
    }
    if(text) apiContent.push({type:"text",text});
    if(apiContent.length===1&&apiContent[0].type==="text") apiContent=apiContent[0].text;
    const nh=[...apiHist,{role:"user",content:apiContent}]; setApiHist(nh);

    try {
      const reply=await callAPI(nh);
      if(reply.includes("|||ENTREGAR_PRODUCTO|||}") || reply.trim()==="|||ENTREGAR_PRODUCTO|||"){
        const m={role:"assistant",content:reply,time:now()}; setMessages(prev=>[...prev,m]);
        const fh=[...nh,{role:"assistant",content:reply}]; setApiHist(fh);
        setLoading(false); await generateProduct(fh); return;
      }
      const dp=detectPhase(reply); if(dp!==null){setPhase(dp);setPhaseDone(prev=>Math.max(prev,dp));}
      const fh=[...nh,{role:"assistant",content:reply}]; setApiHist(fh);
      setMessages(prev=>[...prev,{role:"assistant",content:reply,time:now()}]);
    } catch{setMessages(prev=>[...prev,{role:"assistant",content:"Error. Intenta de nuevo.",time:now()}]);}
    setLoading(false);
  },[input,files,loading,apiHist]);

  const handleKey=(e)=>{ if(e.key==="Enter"&&!e.shiftKey){e.preventDefault();sendMessage();} };
  const PHASES_LABELS=["Diagnóstico","Audiencia","Producto","Precios","Lanzamiento"];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Mono:wght@300;400;500&display=swap');
        *{box-sizing:border-box;margin:0;padding:0;}
        body{background:#000;color:#fff;}
        ::-webkit-scrollbar{width:3px;} ::-webkit-scrollbar-track{background:#050505;} ::-webkit-scrollbar-thumb{background:#dc2626;border-radius:2px;}
        textarea{outline:none;resize:none;}
        @keyframes scanline{0%{top:-1px}100%{top:100vh}}
        @keyframes dp{0%,100%{opacity:.3;transform:scale(.7)}50%{opacity:1;transform:scale(1.1)}}
        @keyframes fadeUp{from{opacity:0;transform:translateY(14px)}to{opacity:1;transform:translateY(0)}}
        @keyframes flicker{0%,100%{opacity:1}93%{opacity:.85}94%{opacity:1}97%{opacity:.9}98%{opacity:1}}
        @keyframes spin{from{transform:rotate(0deg)}to{transform:rotate(360deg)}}
      `}</style>

      <div style={{minHeight:"100vh",background:"#000",position:"relative"}}>
        {/* Grid BG */}
        <div style={{position:"fixed",inset:0,backgroundImage:"linear-gradient(rgba(255,255,255,0.012) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,0.012) 1px,transparent 1px)",backgroundSize:"60px 60px",pointerEvents:"none",zIndex:0}}/>
        {/* Scanline */}
        <div style={{position:"fixed",top:0,left:0,right:0,height:1,background:"linear-gradient(90deg,transparent,rgba(220,38,38,0.12),transparent)",animation:"scanline 7s linear infinite",pointerEvents:"none",zIndex:0}}/>

        {screen==="landing" && <div style={{position:"relative",zIndex:1}}><Landing onStart={startSession}/></div>}

        {screen==="session" && (
          <div style={{display:"flex",flexDirection:"column",height:"100vh",position:"relative",zIndex:1}}>
            {/* Header */}
            <div style={{padding:"0 24px",borderBottom:"1px solid rgba(255,255,255,0.04)",background:"rgba(0,0,0,0.92)",backdropFilter:"blur(10px)",flexShrink:0}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",maxWidth:780,margin:"0 auto",height:54}}>
                <div style={{display:"flex",alignItems:"center",gap:12}}>
                  <span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:14,letterSpacing:"4px",animation:"flicker 9s infinite"}}>IGNITE</span>
                  <div style={{width:1,height:14,background:"rgba(255,255,255,0.08)"}}/>
                  <span style={{fontSize:9,color:"rgba(220,38,38,0.7)",fontFamily:"'DM Mono',monospace",letterSpacing:"2px"}}>{PHASES_LABELS[phase]?.toUpperCase()}</span>
                </div>
                <div style={{display:"flex",alignItems:"center",gap:6}}>
                  <span style={{fontSize:9,color:"rgba(255,255,255,0.15)",fontFamily:"'DM Mono',monospace"}}>FASE {phase+1}/5</span>
                  {PHASES_LABELS.map((_,i)=>(
                    <div key={i} style={{width:24,height:2,borderRadius:1,background:i<phaseDone?"#dc2626":i===phase?"rgba(220,38,38,0.35)":"rgba(255,255,255,0.06)",transition:"background 0.5s"}}/>
                  ))}
                </div>
              </div>
              <div style={{height:1,background:"rgba(220,38,38,0.15)",maxWidth:780,margin:"0 auto"}}/>
            </div>

            {/* Messages */}
            <div style={{flex:1,overflowY:"auto",padding:"28px 24px"}}>
              <div style={{maxWidth:760,margin:"0 auto"}}>
                {messages.map((m,i)=>(
                  <Message key={i} msg={m} onDeliver={()=>generateProduct(apiHist)}/>
                ))}
                {(loading||genLoading) && (
                  <div style={{display:"flex",gap:12,alignItems:"center",marginBottom:20}}>
                    <div style={{width:26,height:26,borderRadius:3,background:"rgba(220,38,38,0.1)",border:"1px solid rgba(220,38,38,0.25)",display:"flex",alignItems:"center",justifyContent:"center",fontSize:8,color:"#dc2626",fontFamily:"'DM Mono',monospace"}}>IGN</div>
                    <div style={{display:"flex",gap:5,alignItems:"center"}}>
                      {[0,1,2].map(i=><div key={i} style={{width:5,height:5,borderRadius:"50%",background:"#dc2626",animation:"dp 1.2s ease-in-out infinite",animationDelay:`${i*0.18}s`}}/>)}
                      <span style={{fontSize:9,color:"rgba(255,255,255,0.2)",fontFamily:"'DM Mono',monospace",marginLeft:8,letterSpacing:"2px"}}>{genLoading?"GENERANDO PRODUCTO":"PROCESANDO"}</span>
                    </div>
                  </div>
                )}
                <div ref={bottomRef}/>
              </div>
            </div>

            {/* Input */}
            <div style={{padding:"14px 24px 18px",borderTop:"1px solid rgba(255,255,255,0.04)",background:"rgba(0,0,0,0.95)",backdropFilter:"blur(10px)",flexShrink:0}}>
              <div style={{maxWidth:760,margin:"0 auto"}}>
                {files.length>0 && (
                  <div style={{display:"flex",flexWrap:"wrap",gap:8,marginBottom:10}}>
                    {files.map((f,i)=>(
                      <div key={i} style={{display:"flex",alignItems:"center",gap:7,padding:"4px 10px",background:"rgba(220,38,38,0.07)",border:"1px solid rgba(220,38,38,0.18)",borderRadius:3}}>
                        <span style={{fontSize:10,color:"rgba(255,255,255,0.5)",fontFamily:"'DM Mono',monospace",maxWidth:120,overflow:"hidden",textOverflow:"ellipsis",whiteSpace:"nowrap"}}>{f.name}</span>
                        <button onClick={()=>setFiles(p=>p.filter((_,j)=>j!==i))} style={{background:"none",border:"none",color:"rgba(220,38,38,0.6)",cursor:"pointer",fontSize:13,lineHeight:1,padding:0}}>×</button>
                      </div>
                    ))}
                  </div>
                )}
                <div
                  onDragOver={e=>{e.preventDefault();setDragOver(true);}}
                  onDragLeave={()=>setDragOver(false)}
                  onDrop={e=>{e.preventDefault();setDragOver(false);handleFiles(e.dataTransfer.files);}}
                  style={{
                    border: dragOver?"1px solid rgba(220,38,38,0.5)":"1px solid rgba(255,255,255,0.07)",
                    borderRadius:3,background:dragOver?"rgba(220,38,38,0.03)":"rgba(255,255,255,0.015)",
                    padding:"12px 14px",transition:"all 0.2s",position:"relative"
                  }}>
                  <textarea ref={taRef} value={input} onChange={e=>{setInput(e.target.value);e.target.style.height="auto";e.target.style.height=Math.min(e.target.scrollHeight,150)+"px";}}
                    onKeyDown={handleKey} disabled={loading||genLoading}
                    placeholder={dragOver?"Suelta aquí los archivos...":"Escribe tu respuesta o arrastra archivos (PDF, imagen, doc, xls, csv)..."}
                    rows={2} style={{width:"100%",background:"transparent",border:"none",color:"rgba(255,255,255,0.8)",fontSize:13,fontFamily:"'DM Mono',monospace",lineHeight:1.7,maxHeight:150,overflow:"auto",caretColor:"#dc2626",paddingRight:70}}/>
                  <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",marginTop:8}}>
                    <button onClick={()=>fileRef.current?.click()} style={{background:"transparent",border:"1px solid rgba(255,255,255,0.06)",color:"rgba(255,255,255,0.3)",padding:"4px 10px",borderRadius:2,cursor:"pointer",fontSize:10,fontFamily:"'DM Mono',monospace",letterSpacing:"1px",transition:"all 0.2s"}}
                      onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(220,38,38,0.35)";e.currentTarget.style.color="#dc2626";}}
                      onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.06)";e.currentTarget.style.color="rgba(255,255,255,0.3)";}}>
                      ⊕ Adjuntar
                    </button>
                    <button onClick={sendMessage} disabled={(!input.trim()&&files.length===0)||loading||genLoading}
                      style={{background:(!input.trim()&&files.length===0)||loading||genLoading?"rgba(255,255,255,0.03)":"#dc2626",border:"none",color:(!input.trim()&&files.length===0)||loading||genLoading?"rgba(255,255,255,0.15)":"#fff",padding:"7px 18px",borderRadius:2,cursor:"pointer",fontSize:9,fontFamily:"'DM Mono',monospace",letterSpacing:"3px",transition:"all 0.2s",textTransform:"uppercase"}}>
                      ENVIAR →
                    </button>
                  </div>
                </div>
                <div style={{textAlign:"center",marginTop:6,fontSize:8,color:"rgba(255,255,255,0.08)",fontFamily:"'DM Mono',monospace",letterSpacing:"2px"}}>ENTER PARA ENVIAR · SHIFT+ENTER NUEVA LÍNEA</div>
              </div>
            </div>
            <input ref={fileRef} type="file" accept="image/*,.pdf,.txt,.md,.csv,.doc,.docx,.xls,.xlsx" multiple style={{display:"none"}} onChange={e=>{handleFiles(e.target.files);e.target.value="";}}/>
          </div>
        )}

        {screen==="product" && courseData && (
          <div style={{position:"relative",zIndex:1,minHeight:"100vh",padding:"0 0 60px"}}>
            {/* Header */}
            <div style={{padding:"0 24px",borderBottom:"1px solid rgba(255,255,255,0.04)",background:"rgba(0,0,0,0.95)",backdropFilter:"blur(10px)",position:"sticky",top:0,zIndex:10}}>
              <div style={{display:"flex",alignItems:"center",justifyContent:"space-between",maxWidth:900,margin:"0 auto",height:54}}>
                <div style={{display:"flex",alignItems:"center",gap:12}}>
                  <span style={{fontFamily:"'Syne',sans-serif",fontWeight:800,fontSize:14,letterSpacing:"4px"}}>IGNITE</span>
                  <div style={{width:1,height:14,background:"rgba(255,255,255,0.08)"}}/>
                  <span style={{fontSize:9,color:"rgba(220,38,38,0.7)",fontFamily:"'DM Mono',monospace",letterSpacing:"2px"}}>PRODUCTO GENERADO</span>
                </div>
                <div style={{display:"flex",gap:8}}>
                  <button onClick={()=>setScreen("session")} style={{background:"transparent",border:"1px solid rgba(255,255,255,0.08)",color:"rgba(255,255,255,0.35)",padding:"6px 14px",borderRadius:2,cursor:"pointer",fontSize:9,fontFamily:"'DM Mono',monospace",letterSpacing:"2px",transition:"all 0.2s"}}
                    onMouseEnter={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.2)";e.currentTarget.style.color="#fff";}}
                    onMouseLeave={e=>{e.currentTarget.style.borderColor="rgba(255,255,255,0.08)";e.currentTarget.style.color="rgba(255,255,255,0.35)";}}>
                    ← Conversación
                  </button>
                  <button onClick={()=>window.location.reload()} style={{background:"transparent",border:"1px solid rgba(220,38,38,0.25)",color:"rgba(220,38,38,0.6)",padding:"6px 14px",borderRadius:2,cursor:"pointer",fontSize:9,fontFamily:"'DM Mono',monospace",letterSpacing:"2px",transition:"all 0.2s"}}
                    onMouseEnter={e=>{e.currentTarget.style.background="rgba(220,38,38,0.1)";e.currentTarget.style.color="#dc2626";}}
                    onMouseLeave={e=>{e.currentTarget.style.background="transparent";e.currentTarget.style.color="rgba(220,38,38,0.6)";}}>
                    Nueva Sesión
                  </button>
                </div>
              </div>
            </div>

            <div style={{maxWidth:900,margin:"0 auto",padding:"32px 24px"}}>
              {/* Success banner */}
              <div style={{
                border:"1px solid rgba(220,38,38,0.2)",borderRadius:4,padding:"20px 28px",
                background:"rgba(220,38,38,0.04)",marginBottom:28,
                display:"flex",alignItems:"center",gap:16
              }}>
                <div style={{width:40,height:40,borderRadius:"50%",background:"rgba(220,38,38,0.1)",border:"1px solid rgba(220,38,38,0.3)",display:"flex",alignItems:"center",justifyContent:"center",flexShrink:0}}>
                  <span style={{fontSize:18}}>⚡</span>
                </div>
                <div>
                  <div style={{fontSize:11,fontWeight:700,color:"#fff",fontFamily:"'Syne',sans-serif",letterSpacing:"-0.3px",marginBottom:3}}>Tu producto digital está listo</div>
                  <div style={{fontSize:11,color:"rgba(255,255,255,0.35)",fontFamily:"'DM Mono',monospace"}}>Landing page · Estructura de módulos · Plan operativo 4 semanas. Personaliza los espacios en blanco con tu contenido real.</div>
                </div>
              </div>

              <CourseLanding course={courseData}/>
            </div>
          </div>
        )}
      </div>
    </>
  );
}
